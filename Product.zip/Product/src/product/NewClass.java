/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package product;

/**
 *
 * @author Mega Store
 */
public class NewClass {
    String Name;
    String ID;
    String Type;
    double UnitPrice;
    int quantity;
    int Buy;
    int Sell;
    
    public NewClass(String n,String i,String t,double u,int q )
    {
        Name = n;
        ID = i;
        Type = t;
        UnitPrice = u;
        quantity = q;
    }
    
    public NewClass()
    {
        Name = "Medicine";
        ID = "302040";
        Type = "Syrup";
        UnitPrice = 30;
        quantity = 50;
    }
    
    int Buy()
    {
        Buy = quantity + Buy;
        return Buy;
    }
    
    int Sell()
    {
        Sell = quantity - Sell;
        return Sell;
    }
    
    String GetData()
    {
        String out = "Name: "+Name+"\n ID: "+ID+"\n Type"+Type+"\n Unit Price: "+
                UnitPrice+"\n Quantity: "+quantity+"\n quantity after buying: ";
        return out;
    }
    
    String GetData1()
    {
        String out = "Name: "+Name+"\n ID: "+ID+"\n Type"+Type+"\n Unit Price: "+
                UnitPrice+"\n Quantity: "+quantity+"\n quantity after Selling: ";
        return out;
    }
}


